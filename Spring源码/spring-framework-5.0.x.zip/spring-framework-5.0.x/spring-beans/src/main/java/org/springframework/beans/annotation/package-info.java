/**
 * Support package for beans-style handling of Java 5 annotations.
 */
@NonNullApi
@NonNullFields
package org.springframework.beans.annotation;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
